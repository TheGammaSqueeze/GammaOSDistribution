// Compile with:
// g++ -g -fpie -o libobj-v1 obj-v1.cc

void
bar()
{}

int main()
{
  bar();

  return 0;
}

