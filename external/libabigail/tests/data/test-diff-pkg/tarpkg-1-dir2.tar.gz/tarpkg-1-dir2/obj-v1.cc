// Compile with:
// g++ -g -fpie -o libobj-v1 obj-v1.cc
//

void
foo()
{}

int main()
{
  foo();

  return 0;
}

