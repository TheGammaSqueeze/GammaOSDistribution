# -*- coding:utf-8 -*-
from .rknn_log import set_log_level_and_file_path
from .rknn_platform import get_host_os_platform, get_librknn_api_require_dll_dir
from .rknn_base import RKNNBase
from argparse import Namespace
import os
import sys
import traceback
import platform

already_imported = False
for path in sys.path:
    if os.path.join('rknn', 'base') in path:
        already_imported = True
if not already_imported:
    lib_path = os.path.abspath(os.path.join(os.path.dirname('__file__'), '..', 'base'))
    sys.path.append(lib_path)


class RKNN:
    """
    Rockchip NN Kit
    """

    # NPU Core Mask
    NPU_CORE_AUTO = 0x0
    NPU_CORE_0 = 0x1
    NPU_CORE_1 = 0x2
    NPU_CORE_2 = 0x4
    NPU_CORE_0_1 = 0x3
    NPU_CORE_0_1_2 = 0x7

    def __init__(self, verbose=False, verbose_file=None):
        if type(verbose) == str:
            verbose = verbose.lower()
        cur_path = os.path.abspath(os.path.join(os.path.dirname('__file__'), '..'))
        if get_host_os_platform() == 'Windows_x64':
            require_dll_dir = get_librknn_api_require_dll_dir()
            new_path = os.environ["PATH"] + ";" + require_dll_dir
            os.environ["PATH"] = new_path
        self.verbose = verbose
        if verbose_file is not None:
            if os.path.dirname(verbose_file) != "" and not os.path.exists(os.path.dirname(verbose_file)):
                verbose_file = None
        self.rknn_log = set_log_level_and_file_path(verbose, verbose_file)
        try:
            import pkg_resources
            self.rknn_log.w('rknn-toolkit2 version: ' + pkg_resources.get_distribution("rknn-toolkit2").version)
        except Exception:
            pass
        if verbose not in [True, False, 'debug']:
            self.rknn_log.e("'verbose' must be True or False!")
        if verbose:
            if verbose_file:
                self.rknn_log.i('Save log info to: {}'.format(verbose_file))
        self.rknn_base = RKNNBase(cur_path, verbose)

    def config(self,
               mean_values=None,
               std_values=None,
               quantized_dtype='asymmetric_quantized-8',
               quantized_algorithm='normal',
               quantized_method='channel',
               target_platform=None,
               quant_img_RGB2BGR=False,
               float_dtype='float16',
               optimization_level=3,
               custom_string=None,
               remove_weight=False,
               compress_weight=False,
               inputs_yuv_fmt=None,
               single_core_mode=False,
               ):
        """
        Configs
        :param mean_values: Channel mean value list.
        :param std_values: Channel std value list.
        :param quantized_dtype: quantize data type, currently support: asymmetric_quantized-8.
        :param quantized_algorithm: currently support: normal, mmse (Min Mean Square Error), kl_divergence.
        :param quantized_method: quantize method, currently support: layer, channel.
        :param target_platform: target chip platform, default is None, means target platform is rk3566. Currently support rk3566 / rk3568 / rk3588 / rv1103 / rv1106.
        :param quant_img_RGB2BGR: whether to do RGB2BGR when load quantize image (jpg/jpeg/png/bmp), default is False.
        :param float_dtype: non quantize data type, currently support: float16, default is float16.
        :param optimization_level: set optimization level, default 3 means use all default optimization options.
        :param custom_string: add custom string information to rknn model, then can query the information at runtime.
        :param remove_weight: generate a slave rknn model which removes conv2d weight, need share weight with rknn model of complete weights.
        :param compress_weight: compress the weights of the model, which can reduce the size of rknn model.
        :param inputs_yuv_fmt: add yuv preprocess at the top of model.
        :param single_core_mode: only for rk3588. single_core_mode=True can reduce the size of rknn model.
        :return: success: 0, failure: -1
        """
        # Workspace args
        args = Namespace()
        args.mean_values = mean_values
        args.std_values = std_values
        args.quantized_dtype = quantized_dtype
        args.quantized_algorithm = quantized_algorithm
        args.quantized_method = quantized_method
        args.target_platform = target_platform
        args.quant_img_RGB2BGR = quant_img_RGB2BGR
        args.float_dtype = float_dtype
        args.optimization_level = optimization_level
        args.custom_string = custom_string
        args.remove_weight = remove_weight
        args.compress_weight = compress_weight
        args.inputs_yuv_fmt = inputs_yuv_fmt
        args.single_core_mode = single_core_mode

        return self.rknn_base.config(args)

    def load_tensorflow(self, tf_pb, inputs, input_size_list, outputs):
        """
        Load TensorFlow Model
        :param tf_pb: TensorFlow model file path. Required.
        :param inputs: Input node list, such as ['input1', 'input2']. Required.
        :param input_size_list: Input size list, such as [[224, 224, 3], [128, 128, 1]]. Required.
        :param outputs: Output node list, such as ['output1', 'output2']. Required.
        :return: success: 0, failure: -1
        """
        return self.rknn_base.load_tensorflow(tf_pb=tf_pb, inputs=inputs,
                                              input_size_list=input_size_list, outputs=outputs)

    def load_caffe(self, model, blobs=None, input_name=None):
        """
        Load Caffe Model
        :param model: Caffe model file
        :param blobs: Caffe blobs file
        :return: success: 0, failure: -1
        """
        return self.rknn_base.load_caffe(model, blobs, input_name)

    def load_tflite(self, model):
        """
        Load TensorFlow Lite Model
        :param model: TensorFlow Lite model file
        :return: success: 0, failure: -1
        """
        return self.rknn_base.load_tflite(model)

    def load_onnx(self, model, inputs=None, input_size_list=None, outputs=None):
        """
        Load ONNX Model
        :param model: ONNX model file
        :param inputs: Specified model inputs, default query from model. Such as: ['data']. Optional.
        :param input_size_list: Set each input tensor size list. For example, [[1,224,224],[3,224,224]] means two input
                                tensors, one shape is [1,224,224], another is [3,224,224]. If inputs set, the
                                input_size_list should be set also.
        :param outputs: Model Outputs, default query from model. Such as: ['resnetv24_dense0_fwd']. Optional.
        :return: success: 0, failure: -1
        """
        return self.rknn_base.load_onnx(model, inputs, input_size_list, outputs)

    def load_darknet(self, model, weight):
        """
        Load Darknet Model
        :param model: darknet model cfg
        :param weight: darknet weight file
        :return: success: 0, failure: -1
        """
        return self.rknn_base.load_darknet(model, weight)

    def load_pytorch(self, model, input_size_list):
        """
        Load pytorch model
        :param model: pytorch traced model file. Required.
        :param input_size_list: Set each input tensor size list. For example, [[1,224,224],[3,224,224]] means two input
                                tensors, one shape is [1,224,224], another is [3,224,224]. Required.
        :return: success: 0, failure: -1
        """
        return self.rknn_base.load_pytorch(model=model, input_size_list=input_size_list)

    def build(self, do_quantization=True, dataset='dataset.txt', rknn_batch_size=-1):
        """
        Build model to graph
        :param do_quantization: Need do quantization
        :param dataset: DataSet for quantization
        :param rknn_batch_size: batch size to inference.
        :return: success: 0, failure: -1
        """

        return self.rknn_base.build(do_quantization=do_quantization, dataset=dataset, expand_batch_size=rknn_batch_size)

    def hybrid_quantization_step1(self, dataset='dataset.txt', rknn_batch_size=-1, proposal=False, proposal_dataset_size=1):
        """
        Generate hybrid quantization config
        :param dataset: DataSet for quantization
        :param rknn_batch_size: batch size to inference.
        :param proposal: Generate hybrid quantization config suggestions
        :param proposal_dataset_size: The size of dataset used for proposal
        :return: success: 0, failure: -1
        """
        return self.rknn_base.hybrid_quantization_step1(
            dataset=dataset, expand_batch_size=rknn_batch_size,
            proposal=proposal, proposal_dataset_size=proposal_dataset_size)

    def hybrid_quantization_step2(self, model_input, data_input, model_quantization_cfg):
        """
        generate rknn model info
        :param model_input: Model file
        :param data_input: Data file
        :param model_quantization_cfg: config file for model quantization
        :return: success: 0, failure: -1
        """
        return self.rknn_base.hybrid_quantization_step2(model_input, data_input, model_quantization_cfg)

    def export_rknn(self, export_path, **kwargs):
        """
        Export rknn model to file
        :param export_path: Export rknn model path
        :return: success: 0, failure: -1
        """
        return self.rknn_base.export_rknn(export_path, **kwargs)

    def export_encrypted_rknn_model(self, input_model, output_model=None, crypt_level=1):
        """
        Encrypt a rknn model.
        :param input_model: path of rknn model which need encrypt, required.
        :param output_model: encrypted rknn model path, optional.
        :param crypt_level: crypt level, 1~3. Default level is 1. The lower the level, the faster the decryption and
                            the lower the security. The higher the level, the slower the decryption and the higher the
                            security.
        :return: success: 0, failure: -1
        """
        if input_model is None:
            self.rknn_log.e('The input_model is None! Please specify input model path!')
            return -1

        if output_model is None:
            output_model_path = os.path.splitext(input_model)[0] + '.crypt.rknn'
            self.rknn_log.w('The output_model is None, using {} as output model name.'.format(output_model_path))
        else:
            output_model_path = output_model

        if crypt_level < 1 or crypt_level > 3:
            crypt_level = 1
            self.rknn_log.w('Unsupport crypt_level {}. It should be 1, 2 or 3. Reset to default: 1.'.format(
                crypt_level))

        return self.rknn_base.get_encrypted_rknn_model(input_model, output_model_path, crypt_level)

    def load_rknn(self, path):
        """
        Load RKNN model
        :param path: RKNN model file path
        :return: success: 0, failure: -1
        """
        return self.rknn_base.load_rknn(path)

    def accuracy_analysis(self, inputs, output_dir='./snapshot', target=None, device_id=None):
        """
        generate inference snapshots (fp32 && qnt) and calculate quantize error.
        :param inputs: DataSet for input (only need one line)
        :param output_dir: Output directory
        :param target: if target is set, individual qnt analysis will analysis the output from NPU.
        :param device_id: if multi devices are connected, device id need be specified.
        """
        return self.rknn_base.accuracy_analysis(inputs, output_dir, target, device_id)

    def init_runtime(self, target=None, target_sub_class=None, device_id=None, perf_debug=False, eval_mem=False,
                     async_mode=False, core_mask=NPU_CORE_AUTO):
        """
        Init run time environment. Needed by called before inference or eval performance.
        :param target: target platform, simulator or rk3566 / rk3568 / rk3588 / rv1103 / rv1106, default is None, means simulator.
        :param target_sub_class: sub class of target, now we only have AI Compute Stick, sub class of rk3566,
                                 value is 'AICS'.
        :param device_id: adb device id, only needed when multiple devices connected to pc
        :param perf_debug: enable or disable debugging performance, it will affect performance
        :param eval_mem: enable or disable debugging memory usage, it will affect performance
        :param async_mode: enable or disable async mode
        :param core_mask: set npu core mask, default is RKNN.NPU_CORE_AUTO, only valid for rk3588, Currently support:
                          RKNN.NPU_CORE_AUTO / RKNN.NPU_CORE_0 / RKNN.NPU_CORE_1 / RKNN.NPU_CORE_2 / RKNN.NPU_CORE_0_1 / RKNN.NPU_CORE_0_1_2
        :return: success: 0, failure: -1
        """

        return self.rknn_base.init_runtime(target=target, target_sub_class=target_sub_class, device_id=device_id,
                                           perf_debug=perf_debug, eval_mem=eval_mem, async_mode=async_mode, core_mask=core_mask)

    def inference(self, inputs, data_format=None, inputs_pass_through=None, get_frame_id=False):
        """
        Run model inference
        :param inputs: Input data List (ndarray list)
        :param data_format: Data format (str), current support: 'nhwc', 'nchw', default is 'nhwc', only valid for 4-dims input. (list)
        :param inputs_pass_through: set pass_through flag(0 or 1: 0 meas False, 1 means True) for every input. (list)
        :param get_frame_id: whether need get output/input frame id when using async mode,it can be use in camera demo
        :return: Output data (ndarray list)
        """
        return self.rknn_base.inference(inputs=inputs, data_format=data_format,
                                        inputs_pass_through=inputs_pass_through, get_frame_id=get_frame_id)

    def eval_perf(self, inputs=None, data_format=None, is_print=True):
        """
        Evaluate model performance
        :param inputs: Input data list (ndarray list).
        :param data_format: Data format (str), currently support: 'nhwc', 'nchw', default is 'nhwc'
        :param is_print: Format print perf result
        :return: Performance Result (dict)
        """
        if inputs is not None:
            self.rknn_log.i('When performing performance evaluation, inputs can be set to None to use fake inputs.')
        if data_format is not None:
            self.rknn_log.i('When performing performance evaluation, data_format can be set to None.')

        return self.rknn_base.eval_perf(is_print)

    def eval_memory(self, is_print=True):
        """
        Get memory usage to evaluate memory loss.
        :param is_print: Format print memory usage
        :return: memory_detail (Dict)
        """
        return self.rknn_base.eval_memory(is_print)

    def list_devices(self):
        """
        print all adb devices and devices use ntb.
        :return: adb_devices, list; ntb_devices, list. example:
                 adb_devices = ['0123456789ABCDEF']
                 ntb_devices = ['TB-RK1808S000000009']
        """
        adb_devices, ntb_devices = self.rknn_base.list_devices()
        self.rknn_log.p('*' * 25)
        if len(adb_devices) > 0:
            self.rknn_log.p('all device(s) with adb mode:')
            self.rknn_log.p(",".join(adb_devices))
        if len(ntb_devices) > 0:
            self.rknn_log.p('all device(s) with ntb mode:')
            self.rknn_log.p(",".join(ntb_devices))
        if len(adb_devices) == 0 and len(ntb_devices) == 0:
            self.rknn_log.p('None devices connected.')
        self.rknn_log.p('*' * 25)
        if len(adb_devices) > 0 and len(ntb_devices) > 0:
            all_adb_devices_are_ntb_also = True
            for device in adb_devices:
                if device not in ntb_devices:
                    all_adb_devices_are_ntb_also = False
            if not all_adb_devices_are_ntb_also:
                self.rknn_log.w('Cannot use both device with adb mode and device with ntb mode.')
        return adb_devices, ntb_devices

    def get_sdk_version(self):
        """
        Get SDK version
        :return: sdk_version
        """
        return self.rknn_base.get_sdk_version()

    def optimize_onnx(self, model, optimized_path=None, passes_enable=None, inputs_for_dump=None):
        """
        Optimize the onnx graph for NPU
        :param model: ONNX model file
        :param optimized_path: the path of optimized ONNX model
        :param passes_enable: the optimzie passes list that need to be enabled, default is None, means enable all passes.
        :param inputs_for_dump: input path (npy) list for dump function, if set, will dump all tensors of simulator.
        :return: success: 0, failure: -1
        """
        return self.rknn_base.optimize_onnx(model, optimized_path, passes_enable, inputs_for_dump)

    def release(self):
        """
        Release RKNN resource
        :return: None
        """
        if platform.machine().lower() != 'amd64':
            # windows can not unsetenv
            os.unsetenv('TMPDIR')
        self.rknn_base.release()
